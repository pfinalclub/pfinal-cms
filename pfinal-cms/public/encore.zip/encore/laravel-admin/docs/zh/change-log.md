# Change log

## v1.2.9、v1.3.3、v1.4.1

- 添加用户设置和修改头像功能
- model-form自定义工具[参考](zh/model-form.md?id=自定义工具)
- 内嵌表单支持[参考](zh/model-form-fields.md?id=embeds)
- 支持自定义导航条（右上角）[参考](https://github.com/z-song/laravel-admin/issues/392)
- 添加脚手架、数据库命令行工具、web artisan帮助工具[参考](zh/helpers.md)
- 支持自定义登陆页面和登陆逻辑[参考](zh/qa.md?id=自定义登陆页面和登陆逻辑)
- 表单支持设置宽度、设置action[参考](zh/model-form.md?id=其它方法)
- 优化表格过滤器
- 修复bug，优化代码和逻辑