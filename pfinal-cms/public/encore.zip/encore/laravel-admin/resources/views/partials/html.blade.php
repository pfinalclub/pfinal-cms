@foreach($html as $item)
    {!! $item !!}
@endforeach
